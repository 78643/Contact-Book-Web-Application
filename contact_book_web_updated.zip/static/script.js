async function loadContacts() {
  let res = await fetch('/api/contacts');
  let contacts = await res.json();
  renderContacts(contacts);
}

function renderContacts(contacts) {
  let list = document.getElementById('contactList');
  list.innerHTML = '';
  contacts.forEach(c => {
    let li = document.createElement('li');
    li.className = 'card';
    li.innerHTML = `<b>${c.name}</b><br>
      📞 ${c.phone || ''}<br>
      📧 ${c.email || ''}<br>
      🏠 ${c.address || ''}<br>
      <button onclick="editContact(${c.id})">✏ Edit</button>
      <button onclick="deleteContact(${c.id})">🗑 Delete</button>`;
    list.appendChild(li);
  });
}

async function deleteContact(id) {
  await fetch('/api/contacts/' + id, { method: 'DELETE' });
  loadContacts();
}

function editContact(id) {
  fetch('/api/contacts').then(r => r.json()).then(contacts => {
    let c = contacts.find(ct => ct.id === id);
    document.getElementById('contactId').value = c.id;
    document.getElementById('name').value = c.name;
    document.getElementById('phone').value = c.phone || '';
    document.getElementById('email').value = c.email || '';
    document.getElementById('address').value = c.address || '';
    document.querySelector('#contactForm button').textContent = 'Update Contact';
  });
}

document.getElementById('contactForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  let id = document.getElementById('contactId').value;
  let contact = {
    name: document.getElementById('name').value,
    phone: document.getElementById('phone').value,
    email: document.getElementById('email').value,
    address: document.getElementById('address').value
  };
  let res;
  if (id) {
    res = await fetch('/api/contacts/' + id, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(contact)
    });
  } else {
    res = await fetch('/api/contacts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(contact)
    });
  }
  if (res.ok) {
    document.getElementById('contactForm').reset();
    document.querySelector('#contactForm button').textContent = 'Add Contact';
    loadContacts();
  } else {
    let err = await res.json();
    alert(err.error);
  }
});

async function searchContact() {
  let name = document.getElementById('searchInput').value;
  let res = await fetch('/api/search?name=' + name);
  let results = await res.json();
  renderContacts(results);
}

loadContacts();
