from flask import Flask, render_template, request, jsonify
import json, os, re

app = Flask(__name__)
DATA_FILE = "contacts.json"

# Helper functions
def load_contacts():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_contacts(contacts):
    with open(DATA_FILE, "w") as f:
        json.dump(contacts, f, indent=4)

def validate_contact(contact):
    # Phone validation (only digits)
    if contact.get("phone") and not contact["phone"].isdigit():
        return False, "Phone number must contain only digits."
    # Gmail validation
    if contact.get("email") and not re.match(r"^[A-Za-z0-9._%+-]+@gmail\.com$", contact["email"]):
        return False, "Email must be a valid Gmail address."
    return True, ""

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/contacts", methods=["GET"])
def get_contacts():
    return jsonify(load_contacts())

@app.route("/api/contacts", methods=["POST"])
def add_contact():
    contacts = load_contacts()
    new_contact = request.json
    valid, msg = validate_contact(new_contact)
    if not valid:
        return jsonify({"error": msg}), 400
    new_contact["id"] = len(contacts) + 1
    contacts.append(new_contact)
    save_contacts(contacts)
    return jsonify(new_contact), 201

@app.route("/api/contacts/<int:cid>", methods=["DELETE"])
def delete_contact(cid):
    contacts = load_contacts()
    contacts = [c for c in contacts if c["id"] != cid]
    save_contacts(contacts)
    return "", 204

@app.route("/api/contacts/<int:cid>", methods=["PUT"])
def update_contact(cid):
    contacts = load_contacts()
    for contact in contacts:
        if contact["id"] == cid:
            data = request.json
            valid, msg = validate_contact(data)
            if not valid:
                return jsonify({"error": msg}), 400
            contact.update(data)
            save_contacts(contacts)
            return jsonify(contact)
    return jsonify({"error": "Not found"}), 404

@app.route("/api/search", methods=["GET"])
def search_contact():
    name = request.args.get("name", "").lower()
    contacts = load_contacts()
    results = [c for c in contacts if name in c["name"].lower()]
    return jsonify(results)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
